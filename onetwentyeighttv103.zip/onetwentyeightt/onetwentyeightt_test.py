import uuid
import json
import urllib.request, urllib.error, urllib.parse
import time
import logging
import re
import urllib.request
import ssl
from time import gmtime, strftime, sleep
from datetime import datetime, timedelta
from typing import Pattern, Dict, Union

logging.info("Start of 128T Test")

# CONFIGURATION
# All server configuration fields will be available in the 'params' dictionary.
ONETWENTYEIGHTT_URL = params["connect_128t_url"] # Server URL
ONETWENTYEIGHTT_USERNAME = params["connect_128t_username"]  # Username
ONETWENTYEIGHTT_PASSWORD = params["connect_128t_pw"]  # Password



context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
 
_handlers = []
_handlers.append(urllib.request.HTTPCookieProcessor())
_handlers.append(urllib.request.HTTPSHandler(context=context))
_opener = urllib.request.build_opener(*_handlers)

#Let's get the bearer token
user_headers = {"Content-Type": "application/json; charset=utf-8"}
# Get the username and password from our properties file
payload = {'username': ONETWENTYEIGHTT_USERNAME, 'password': ONETWENTYEIGHTT_PASSWORD}
#logging.info('\n username = {}, password = {}'.format(ONETWENTYEIGHTT_USERNAME, ONETWENTYEIGHTT_PASSWORD))
payloadt = urllib.parse.urlencode(payload).encode("utf-8")
payloadt = json.dumps(payload).encode("utf-8")
#logging.info('\n payloadt = {}'.format(payloadt))
# Build the request with the correct url appending /v1/login and sending our username/password and standard JSON headers
request_token = urllib.request.Request(ONETWENTYEIGHTT_URL + '/v1/login', payloadt, user_headers)
token_resp = _opener.open(request_token, timeout=100)
_current_status_code = token_resp.getcode()
token_r = token_resp.read()
# Convert the response to standard JSON and then pull out the raw text of the bearer token to be used in our next request.
token = json.loads(token_r.decode("utf-8"))
bearer_token = token["token"]
#logging.info(token["token"])


headers = {"Content-Type": "application/json; charset=utf-8", "Authorization": 'Bearer ' + bearer_token}
payload = {'query':'query getArp($filterNodes: [String], $filterRouters: [String]) {allRouters(names: $filterRouters) {nodes {name nodes(names: $filterNodes) {nodes {_id name arp {devicePort ipAddress destinationMac}}}}}}','variables':{'filterRouters':None,'filterNodes':None},'operationName':'getArp'}
dataa = urllib.parse.urlencode(payload).encode("utf-8")
dataa = json.dumps(payload).encode("utf-8")
request = urllib.request.Request(ONETWENTYEIGHTT_URL + '/v1/graphql', dataa, headers)


resp = _opener.open(request, timeout=100)
_current_status_code = resp.getcode()

r = resp.read()
dataa = json.loads(r.decode("utf-8"))

# Now that we have the response, let's figure out how many routers there are
# so we an build a for loop to step through them all
numRouters = len(dataa["data"]["allRouters"]["nodes"])

# ***** response is the return for the script, properties contains the property names and values
response = {}


numARP = 0

# Lets loop for the number of routers
for i in range(numRouters):

   # Get the JSON string of the properties under the router
   prop = dataa["data"]["allRouters"]["nodes"][i]

   # Let's get the name of the router for these ARP entries
   routerName = prop['name']

   # OK, Let's loop for each of the property sets
   # for prop_key, prop_val in prop.items():
   arpTable = dataa["data"]["allRouters"]["nodes"][i]["nodes"]["nodes"][0]
   for key, value in arpTable.items():
        # print('key = {} Value = {}'.format(key,value))
        if ( "arp" in key and value != None ):
            for entry in value:
                numARP = numARP + 1
                devicePort = entry['devicePort']
                #print ('devicePort = {}'.format(devicePort))
                ipAddress = entry['ipAddress']
                #print ('ipAddress = {}'.format(ipAddress))
                destinationMac = entry['destinationMac']
                #print ('destinationMac = {}'.format(destinationMac))
                logging.info('All Host Properties: ipAddress: {}, \nmacAddress: {}, \nRouter: {}, \nPort: {}\n\n'.format(ipAddress,destinationMac,routerName,devicePort))

# Like the action response, the response object must have a "succeeded" field to denote success. It can also optionally have 
# a "result_msg" field to display a custom test result message.


# We want to return the number of routers found and the number of ARP entries to give the user a nice warm fuzzy feeling


if _current_status_code == 200:
    logging.info("inside 200")
    response["succeeded"] = True
    response["result_msg"] = "Successfully connected: \n    Number of Routers: {}\n    Number of ARP entries: {}".format(numRouters, numARP)
else:
    logging.info("inside else")
    response["succeeded"] = False
    response["result_msg"] = "Could not connect to 128T server."