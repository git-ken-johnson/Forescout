import uuid
import json
import urllib.request, urllib.error, urllib.parse
import time
import logging
import re
import urllib.request
import ssl
from time import gmtime, strftime, sleep
from datetime import datetime, timedelta
from typing import Pattern, Dict, Union

logging.info("Starting 128T eyeExtend Connect ONETWENTYEIGHTT_poll.py script")
logging.info("more starting this time, really")

# ***** Mapping between 128t API response fields to CounterACT properties *****
onetwentyeightt_to_ct_props_map = {
    "ipAddress": "connect_onetwentyeightt_ipAddress",
    "destinationMac": "connect_onetwentyeightt_destinationMac",
    "routerNode": "connect_onetwentyeightt_routerNode",
    "deviceInterface": "connect_onetwentyeightt_deviceInterface",
    "routerName": "connect_onetwentyeightt_routerName",
    "state": "connect_onetwentyeightt_state"
}

# CONFIGURATION
# All server configuration fields will be available in the 'params' dictionary.
ONETWENTYEIGHTT_URL = params["connect_128t_url"] # Server URL
ONETWENTYEIGHTT_USERNAME = params["connect_128t_username"]  # Username
ONETWENTYEIGHTT_PASSWORD = params["connect_128t_pw"]  # Password

context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
 
_handlers = []
_handlers.append(urllib.request.HTTPCookieProcessor())
_handlers.append(urllib.request.HTTPSHandler(context=context))
_opener = urllib.request.build_opener(*_handlers)

#Let's get the bearer token
user_headers = {"Content-Type": "application/json; charset=utf-8"}
# Get the username and password from our properties file and convert to JSON encoded as utf-8
payload = {'username': ONETWENTYEIGHTT_USERNAME, 'password': ONETWENTYEIGHTT_PASSWORD}
payloadt = urllib.parse.urlencode(payload).encode("utf-8")
payloadt = json.dumps(payload).encode("utf-8")
# Build the request with the correct url appending /v1/login and sending our username/password and standard JSON headers
request_token = urllib.request.Request(ONETWENTYEIGHTT_URL + '/v1/login', payloadt, user_headers)
token_resp = _opener.open(request_token, timeout=100)
_current_status_code = token_resp.getcode()
token_r = token_resp.read()
# Convert the response to standard JSON and then pull out the raw text of the bearer token to be used in our next request.
token = json.loads(token_r.decode("utf-8"))
bearer_token = token["token"]



# Set up the new headers with the bearer token we just went and acquired
headers = {"Content-Type": "application/json; charset=utf-8", "Authorization": 'Bearer ' + bearer_token}
# Set up the payload to get 4 specific arguments from the ARP table, state, deviceInterface, ipAddress and destinationMac
payload = {'query':'query getArp($filterNodes: [String], $filterRouters: [String]) {allRouters(names: $filterRouters) {nodes {name nodes(names: $filterNodes) {nodes {_id name arp {deviceInterface ipAddress destinationMac state}}}}}}','variables':{'filterRouters':None,'filterNodes':None},'operationName':'getArp'}
dataa = urllib.parse.urlencode(payload).encode("utf-8")
dataa = json.dumps(payload).encode("utf-8")
request = urllib.request.Request(ONETWENTYEIGHTT_URL + '/v1/graphql', dataa, headers)
#logging.info('request = {}'.format(request))

resp = _opener.open(request, timeout=100)
_current_status_code = resp.getcode()

r = resp.read()
#Load up the response from JSON into python so we can easily extract the data
dataa = json.loads(r.decode("utf-8"))

# Now that we have the response, let's figure out how many routers there are
# so we an build a for loop to step through them all
numRouters = len(dataa["data"]["allRouters"]["nodes"])

# ***** response is the return for the script, properties contains the property names and values
response = {}
properties = {}
endpoints=[]

# logging.info("Looping through Routers")
# Lets loop for the number of routers
for i in range(numRouters):

   # Get the JSON string of the properties under the router
   prop = dataa["data"]["allRouters"]["nodes"][i]

   # Let's get the name of the router for these ARP entries
   routerName = prop['name']

   # OK, Let's loop for each of the property sets
   # for prop_key, prop_val in prop.items():
   arpTable = dataa["data"]["allRouters"]["nodes"][i]["nodes"]["nodes"][0]
   logging.info('dataa = {}'.format(dataa))
   for key, value in arpTable.items():
        logging.info("Looping through ARP")
        if ( "name"  in key and value != None):
            logging.info('/nkey = {} Value = {}/n'.format(key,value))
            routerNode = {}
            routerNode = value
            logging.info('RouterNode = {}'.format(routerNode))
            
        if ( "arp" in key and value != None ):
            for entry in value:
                logging.info("Looping through ARP Entry")
                logging.info("State is {}".format(entry['state']))
                if ( "Static" in entry['state'] or "Valid" in entry['state'] ):
                    endpoint = {}
                    props = {}
                    endpoint["ip"] = entry['ipAddress']
                    destinationMac = entry['destinationMac']
                    endpoint["mac"] = "".join(destinationMac.split(":"))
                    props["connect_onetwentyeightt_ipAddress"] = entry['ipAddress']
                    props["connect_onetwentyeightt_destinationMac"] = destinationMac
                    props["connect_onetwentyeightt_routerNode"] = routerNode
                    props["connect_onetwentyeightt_deviceInterface"] = entry['deviceInterface']
                    props["connect_onetwentyeightt_routerName"] = routerName
                    props["connect_onetwentyeightt_state"] = entry['state']
                
                    endpoint["properties"] = props
                    endpoints.append(endpoint)
                
                


logging.info("Outside the Loops")
logging.info("Returning response object to infrastructure. response={}".format(endpoints))
response["endpoints"] = endpoints