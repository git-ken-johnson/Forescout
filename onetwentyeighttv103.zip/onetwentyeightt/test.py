import json
import re
from typing import Pattern, Dict, Union
import urllib.request
import ssl

context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

_handlers = []
_handlers.append(urllib.request.HTTPCookieProcessor())
_handlers.append(urllib.request.HTTPSHandler(context=context))
_opener = urllib.request.build_opener(*_handlers)
headers = {"Content-Type": "application/json; charset=utf-8", "Authorization": "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiYWRtaW4iLCJzY29wZXMiOlsiY29uZmlndXJlIl0sImlhdCI6MTU4NTA5NjgwOX0.V8IvjkuWTEjdpxTvpNmMxkEQ63S8T93yn8tHNC58d1RwEao6RTUuVGyAaCFd9n_e_65bRELhp4MaoXdFHs3gxxTQE5_D-DGL0p4RneaWQWoqyeNbI1AwPZ4PN0ySVpQJNReBIbraeiKNhNL-2XCrsxs56JQIMniP1WaIPWVltp6ZkIEpBaz9luYMTliHFvqaUnKWA1OJ9aZ45y9eP8j2PFaq5fpE0TuRpKdxHBnxOOiEtZqKnEmusa4aRH8B1asP0L7zYAUhnXZ3lziuO6fDi9MILPWlyzLwbBn2wYH0dbAVTEIeeZdFTC-kEOVtzDwEfxdGAYuDFFcmv0li_rkFng"}
payload = {'query':'query getArp($filterNodes: [String], $filterRouters: [String]) {allRouters(names: $filterRouters) {nodes {name nodes(names: $filterNodes) {nodes {_id name arp {devicePort ipAddress destinationMac}}}}}}','variables':{'filterRouters':None,'filterNodes':None},'operationName':'getArp'}
dataa = urllib.parse.urlencode(payload).encode("utf-8")
dataa = json.dumps(payload).encode("utf-8")
request = urllib.request.Request("https://10.1.3.215/api/v1/graphql", dataa, headers)


resp = _opener.open(request, timeout=100)
_current_status_code = resp.getcode()

r = resp.read()
dataa = json.loads(r.decode("utf-8"))


# data_results = dataa["data"]["allRouters"]["nodes"]["nodes"]["nodes"]["arp"]["devicePort"][0]

# Output: ['English', 'French']
# print(person_dict['languages'])

# print(dataa["data"]["allRouters"]["nodes"][1]["nodes"]["nodes"][0]["arp"]["devicePort"]

# print('Successfully connected: request_response: {}'.format(dataa))
# print('')
# print('')
# count = 1;

count = len(dataa["data"]["allRouters"]["nodes"])
print('# of Routers = {}'.format(count))
print('')

for i in range(count):
    prop = dataa["data"]["allRouters"]["nodes"][i]
    for prop_key, prop_val in prop.items():
        # print(count)
        # count = count + 1
        print('prop_key = {}  -  prop_val = {}'.format(prop_key,prop_val))
        print('\n')
        count = count + 1
